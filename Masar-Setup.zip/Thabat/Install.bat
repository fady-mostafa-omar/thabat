@echo off
rem Thabat installer launcher (fallback for "Thabat Setup.exe"). Double-click this file.
cd /d "%~dp0"
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0files\installer.ps1"
exit /b 0
