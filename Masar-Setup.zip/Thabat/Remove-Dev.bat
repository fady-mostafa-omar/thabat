@echo off
rem TEST BUILDS ONLY. Removes Thabat from the connected phone without wiping it.
rem Works because test builds are testOnly and keep adb enabled.
cd /d "%~dp0"
set "ADB=%~dp0files\platform-tools\adb.exe"
if not exist "%ADB%" (
  echo platform-tools not found. Run "Thabat Setup.exe" once first.
  pause
  exit /b 1
)
echo This removes Thabat from the connected phone (test builds only).
pause
"%ADB%" shell content call --uri content://com.thabat.app.status --method dev_lift
"%ADB%" shell dpm remove-active-admin com.thabat.app/.admin.ThabatAdminReceiver
"%ADB%" uninstall com.thabat.app
echo.
echo Done. If you see errors above, send a screenshot.
pause
