﻿# Thabat - laptop installer (Windows PowerShell 5.1 + WinForms).
# Saved as UTF-8 with BOM so Windows PowerShell reads the Arabic text correctly.
# Started by "Thabat Setup.exe" (or Install.bat). Everything runs on the UI thread;
# long adb calls keep the window responsive by pumping messages while they wait.

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$Pkg = 'com.thabat.app'
$Admin = 'com.thabat.app/.admin.ThabatAdminReceiver'
$Here = $PSScriptRoot
if (-not $Here) { $Here = Split-Path -Parent $MyInvocation.MyCommand.Path }
$script:Adb = Join-Path $Here 'platform-tools\adb.exe'
$PlatformToolsUrl = 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip'
$StateDir = Join-Path $env:LOCALAPPDATA 'Thabat'
New-Item -ItemType Directory -Force -Path $StateDir | Out-Null

$script:En = $false
$script:Cancelled = $false
$script:UserDone = $false
$script:UserSkip = $false
$script:CurrentStep = 0
$script:Model = 'phone'
$script:Maker = ''
$script:Serial = ''
$script:BackupDir = $null
$script:OursIsOwner = $false
$script:Frozen = @()
$script:AccountsBefore = @()

function T([string]$ar, [string]$en) { if ($script:En) { return $en } else { return $ar } }

# ---------------------------------------------------------------- colors

function RGB([int]$r, [int]$g, [int]$b) { [System.Drawing.Color]::FromArgb($r, $g, $b) }
$Ink    = RGB 31 42 46
$Muted  = RGB 94 107 112
$Brand  = RGB 16 165 148
$BrandSoft = RGB 215 245 239
$Sun    = RGB 255 190 46
$SunSoft = RGB 255 242 204
$Coral  = RGB 255 107 74
$Active = RGB 46 155 240
$Fail   = RGB 214 69 50
$Ground = RGB 255 251 240

# ---------------------------------------------------------------- window

$form = New-Object System.Windows.Forms.Form
$form.ClientSize = New-Object System.Drawing.Size(760, 640)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.BackColor = $Ground
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
try {
    $exe = Join-Path (Split-Path -Parent $Here) 'Thabat Setup.exe'
    if (Test-Path $exe) { $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($exe) }
} catch {}

function New-Label([int]$x, [int]$y, [int]$w, [int]$h, [single]$size = 10, [bool]$bold = $false) {
    $l = New-Object System.Windows.Forms.Label
    $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size($w, $h)
    $style = if ($bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
    $l.Font = New-Object System.Drawing.Font('Segoe UI', $size, $style)
    $l.ForeColor = $Ink
    $form.Controls.Add($l)
    return $l
}

function New-Button([int]$x, [int]$y, [int]$w, [int]$h) {
    $b = New-Object System.Windows.Forms.Button
    $b.Location = New-Object System.Drawing.Point($x, $y)
    $b.Size = New-Object System.Drawing.Size($w, $h)
    $b.FlatStyle = 'Flat'
    $b.BackColor = [System.Drawing.Color]::White
    $form.Controls.Add($b)
    return $b
}

$lblTitle = New-Label 24 14 712 40 17 $true
$lblTitle.ForeColor = $Brand

# ---- start page
$btnAr = New-Button 24 66 150 38
$btnAr.Text = 'العربي'
$btnEn = New-Button 184 66 150 38
$btnEn.Text = 'English'

$lblPhone = New-Label 24 120 712 26 11 $true
$rbAndroid = New-Object System.Windows.Forms.RadioButton
$rbAndroid.Location = New-Object System.Drawing.Point(24, 150)
$rbAndroid.Size = New-Object System.Drawing.Size(220, 28)
$rbAndroid.Checked = $true
$form.Controls.Add($rbAndroid)
$rbIphone = New-Object System.Windows.Forms.RadioButton
$rbIphone.Location = New-Object System.Drawing.Point(260, 150)
$rbIphone.Size = New-Object System.Drawing.Size(220, 28)
$form.Controls.Add($rbIphone)

$lblBrand = New-Label 24 192 712 26 11 $true
$cmbBrand = New-Object System.Windows.Forms.ComboBox
$cmbBrand.Location = New-Object System.Drawing.Point(24, 222)
$cmbBrand.Size = New-Object System.Drawing.Size(320, 30)
$cmbBrand.DropDownStyle = 'DropDownList'
$form.Controls.Add($cmbBrand)

$lblHelp = New-Label 340 66 396 440 11
$lblHelp.BackColor = [System.Drawing.Color]::White
$lblHelp.Padding = New-Object System.Windows.Forms.Padding(12)

# Phone drawing next to the help text (see Draw-HelpPicture).
$picHelp = New-Object System.Windows.Forms.PictureBox
$picHelp.Location = New-Object System.Drawing.Point(24, 66)
$picHelp.Size = New-Object System.Drawing.Size(300, 440)
$picHelp.BackColor = $Ground
$form.Controls.Add($picHelp)

$chkBackup = New-Object System.Windows.Forms.CheckBox
$chkBackup.Location = New-Object System.Drawing.Point(340, 512)
$chkBackup.Size = New-Object System.Drawing.Size(396, 56)
$chkBackup.Checked = $true
$form.Controls.Add($chkBackup)

# Arabic only, Android only, no brand choice (agreed 2026-11-05): these stay hidden.
foreach ($c in @($btnAr, $btnEn, $lblPhone, $rbAndroid, $rbIphone, $lblBrand, $cmbBrand)) { $c.Visible = $false }

# ---- run page
$StepKeys = @('tools', 'connect', 'check', 'backup', 'accounts', 'install', 'setup', 'restore')
$StepLabels = @()
for ($i = 0; $i -lt $StepKeys.Count; $i++) {
    $StepLabels += (New-Label 24 (66 + $i * 34) 250 28 10.5)
}
$lblMsg = New-Label 290 66 446 190 11

$lstAccounts = New-Object System.Windows.Forms.ListBox
$lstAccounts.Location = New-Object System.Drawing.Point(290, 262)
$lstAccounts.Size = New-Object System.Drawing.Size(446, 96)
$form.Controls.Add($lstAccounts)

$btnAction = New-Button 290 366 260 34
$btnAction2 = New-Button 560 366 176 34

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Location = New-Object System.Drawing.Point(290, 408)
$progress.Size = New-Object System.Drawing.Size(446, 22)
$progress.Style = 'Marquee'
$form.Controls.Add($progress)

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Location = New-Object System.Drawing.Point(24, 430)
$txtLog.Size = New-Object System.Drawing.Size(712, 130)
$txtLog.Multiline = $true
$txtLog.ReadOnly = $true
$txtLog.ScrollBars = 'Vertical'
$txtLog.RightToLeft = 'No'
$txtLog.Font = New-Object System.Drawing.Font('Consolas', 8.5)
$txtLog.Visible = $false
$form.Controls.Add($txtLog)

$lnkDetails = New-Object System.Windows.Forms.LinkLabel
$lnkDetails.Location = New-Object System.Drawing.Point(24, 404)
$lnkDetails.Size = New-Object System.Drawing.Size(240, 22)
$lnkDetails.LinkColor = $Muted
$form.Controls.Add($lnkDetails)

$picDone = New-Object System.Windows.Forms.PictureBox
$picDone.Location = New-Object System.Drawing.Point(290, 66)
$picDone.Size = New-Object System.Drawing.Size(446, 140)
$picDone.Visible = $false
$form.Controls.Add($picDone)

# ---- bottom buttons
$btnStart = New-Button 24 580 200 44
$btnStart.Font = New-Object System.Drawing.Font('Segoe UI', 11.5, [System.Drawing.FontStyle]::Bold)
$btnStart.BackColor = $Brand
$btnStart.ForeColor = [System.Drawing.Color]::White
$btnClose = New-Button 616 580 120 44
$btnBack = New-Button 234 580 150 44
foreach ($b in @($btnClose, $btnBack)) { $b.FlatAppearance.BorderColor = $Brand; $b.ForeColor = $Brand }
$btnStart.FlatAppearance.BorderSize = 0

$StartControls = @($lblHelp, $picHelp, $chkBackup, $btnBack)
$RunControls = @($lblMsg, $lstAccounts, $btnAction, $btnAction2, $progress, $lnkDetails) + $StepLabels

# ---------------------------------------------------------------- texts

$Brands = @('oplus', 'samsung', 'xiaomi', 'vivo', 'huawei', 'other')

function Brand-Name([string]$key) {
    switch ($key) {
        'oplus'   { return (T 'أوبو / ريلمي / وان بلس' 'OPPO / realme / OnePlus') }
        'samsung' { return (T 'سامسونج' 'Samsung') }
        'xiaomi'  { return (T 'شاومي / ريدمي / بوكو' 'Xiaomi / Redmi / POCO') }
        'vivo'    { return (T 'فيفو' 'vivo') }
        'huawei'  { return (T 'هواوي / أونر' 'Huawei / Honor') }
        default   { return (T 'نوع تاني' 'Other') }
    }
}

function Brand-Help([string]$key) {
    $intro = T "مرة واحدة على الموبايل، قبل ما تدوس (ابدأ):`n`n" "Once, on the phone, before pressing (Start):`n`n"
    $after = T "`n`nبعدها وصّل الموبايل باللابتوب بالكابل، ودوس (ابدأ)." "`n`nThen connect the phone to the laptop with a cable and press (Start)."
    switch ($key) {
        'oplus' {
            return $intro + (T ("1) الإعدادات ← عن الهاتف ← الإصدار ← دوس 7 مرات على (رقم الإصدار) لحد ما يقول إنك بقيت مطوّر.`n" +
                "2) ارجع للإعدادات ← إعدادات إضافية ← خيارات المطوّر.`n" +
                "3) شغّل (تصحيح أخطاء USB).`n" +
                "4) في نفس الصفحة تحت خالص: شغّل (تعطيل مراقبة الأذونات).") `
                ("1) Settings > About phone > Version > tap (Build number) 7 times until it says you are a developer.`n" +
                "2) Back to Settings > Additional settings > Developer options.`n" +
                "3) Turn on (USB debugging).`n" +
                "4) At the bottom of the same page: turn on (Disable permission monitoring).")) + $after
        }
        'samsung' {
            return $intro + (T ("1) الإعدادات ← حول الهاتف ← معلومات البرنامج ← دوس 7 مرات على (رقم الإصدار).`n" +
                "2) ارجع للإعدادات ← خيارات المطور (تحت خالص).`n" +
                "3) شغّل (تصحيح أخطاء USB).") `
                ("1) Settings > About phone > Software information > tap (Build number) 7 times.`n" +
                "2) Back to Settings > Developer options (at the bottom).`n" +
                "3) Turn on (USB debugging).")) + $after
        }
        'xiaomi' {
            return $intro + (T ("1) الإعدادات ← حول الهاتف ← دوس 7 مرات على (إصدار MIUI) أو (إصدار نظام التشغيل).`n" +
                "2) الإعدادات ← إعدادات إضافية ← خيارات المطور.`n" +
                "3) شغّل (تصحيح أخطاء USB) و(تصحيح أخطاء USB (إعدادات الأمان)) و(التثبيت عبر USB).`n" +
                "   شاومي ممكن تطلب شريحة في الموبايل وتسجيل دخول لحساب Mi.") `
                ("1) Settings > About phone > tap (MIUI version) or (OS version) 7 times.`n" +
                "2) Settings > Additional settings > Developer options.`n" +
                "3) Turn on (USB debugging), (USB debugging (Security settings)) and (Install via USB).`n" +
                "   Xiaomi may ask for a SIM card and a Mi account sign-in.")) + $after
        }
        'vivo' {
            return $intro + (T ("1) الإعدادات ← إدارة النظام ← حول الهاتف ← معلومات الإصدار ← دوس 7 مرات على (إصدار البرنامج).`n" +
                "2) الإعدادات ← إدارة النظام ← خيارات المطور.`n" +
                "3) شغّل (تصحيح أخطاء USB).") `
                ("1) Settings > System management > About phone > Version info > tap (Software version) 7 times.`n" +
                "2) Settings > System management > Developer options.`n" +
                "3) Turn on (USB debugging).")) + $after
        }
        'huawei' {
            return $intro + (T ("1) الإعدادات ← حول الهاتف ← دوس 7 مرات على (رقم الإصدار).`n" +
                "2) الإعدادات ← النظام والتحديثات ← خيارات المطور.`n" +
                "3) شغّل (تصحيح أخطاء USB).`n`n" +
                "بصراحة: موبايلات هواوي وأونر غالباً مش بتسمح بالتفعيل. جرّب، ولو فشل مفيش ضرر.") `
                ("1) Settings > About phone > tap (Build number) 7 times.`n" +
                "2) Settings > System & updates > Developer options.`n" +
                "3) Turn on (USB debugging).`n`n" +
                "Honestly: Huawei and Honor phones often do not allow activation. Trying does no harm.")) + $after
        }
        default {
            return $intro + (T ("1) الإعدادات ← عن الهاتف ← دوس 7 مرات على (رقم الإصدار / Build number).`n" +
                "2) دوّر في الإعدادات على (خيارات المطور / Developer options).`n" +
                "3) شغّل (تصحيح أخطاء USB / USB debugging).") `
                ("1) Settings > About phone > tap (Build number) 7 times.`n" +
                "2) Find (Developer options) in Settings.`n" +
                "3) Turn on (USB debugging).")) + $after
        }
    }
}

function Step-Name([int]$i) {
    switch ($StepKeys[$i]) {
        'tools'    { return (T 'تجهيز أدوات أندرويد' 'Android tools') }
        'connect'  { return (T 'توصيل الموبايل' 'Connect the phone') }
        'check'    { return (T 'فحص الموبايل' 'Check the phone') }
        'backup'   { return (T 'نسخة احتياطية' 'Backup') }
        'accounts' { return (T 'الحسابات' 'Accounts') }
        'install'  { return (T 'تثبيت وتفعيل البرنامج' 'Install and activate') }
        'setup'    { return (T 'الإعداد على الموبايل' 'Setup on the phone') }
        'restore'  { return (T 'نرجّع كل حاجة زي ما كانت' 'Bring everything back') }
    }
}

# ---------------------------------------------------------------- pictures
# Phone drawings that show where to tap, step by step. Drawn with GDI+: no image files.
# Each step: a screen title, a few rows, the row to touch (Hi) and what to do there:
# tap, tap7 (tap 7 times), on (switch on) or check.

function S([string]$tAr, [string]$tEn, [string]$rAr, [string]$rEn, [int]$hi, [string]$mark) {
    return [pscustomobject]@{ TAr = $tAr; TEn = $tEn; RAr = $rAr.Split('|'); REn = $rEn.Split('|'); Hi = $hi; Mark = $mark }
}

function Help-Pics([string]$key) {
    switch ($key) {
        'oplus' { return @(
            (S 'الإعدادات' 'Settings' 'البطارية|إعدادات إضافية|عن الهاتف' 'Battery|Additional settings|About phone' 2 'tap'),
            (S 'عن الهاتف' 'About phone' 'اسم الجهاز|الطراز|الإصدار' 'Device name|Model|Version' 2 'tap'),
            (S 'الإصدار' 'Version' 'إصدار Android|رقم الإصدار|Baseband & Kernel' 'Android version|Build number|Baseband & kernel' 1 'tap7'),
            (S 'إعدادات إضافية' 'Additional settings' 'التاريخ والوقت|اللغة|خيارات المطوّر' 'Date & time|Language|Developer options' 2 'tap'),
            (S 'خيارات المطوّر' 'Developer options' 'تصحيح أخطاء USB|إعدادات أخرى|…' 'USB debugging|Other settings|…' 0 'on'),
            (S 'خيارات المطوّر (تحت خالص)' 'Developer options (bottom)' '…|…|تعطيل مراقبة الأذونات' '…|…|Disable permission monitoring' 2 'on')) }
        'samsung' { return @(
            (S 'الإعدادات' 'Settings' 'إدارة عامة|تحديث البرنامج|حول الهاتف' 'General management|Software update|About phone' 2 'tap'),
            (S 'حول الهاتف' 'About phone' 'معلومات الحالة|معلومات البرنامج|معلومات البطارية' 'Status information|Software information|Battery information' 1 'tap'),
            (S 'معلومات البرنامج' 'Software information' 'إصدار One UI|إصدار Android|رقم الإصدار' 'One UI version|Android version|Build number' 2 'tap7'),
            (S 'الإعدادات' 'Settings' 'تحديث البرنامج|حول الهاتف|خيارات المطور' 'Software update|About phone|Developer options' 2 'tap'),
            (S 'خيارات المطور' 'Developer options' 'تصحيح أخطاء USB|…|…' 'USB debugging|…|…' 0 'on')) }
        'xiaomi' { return @(
            (S 'الإعدادات' 'Settings' 'حول الهاتف|البطارية|إعدادات إضافية' 'About phone|Battery|Additional settings' 0 'tap'),
            (S 'حول الهاتف' 'About phone' 'اسم الجهاز|إصدار MIUI|الذاكرة' 'Device name|MIUI version|Storage' 1 'tap7'),
            (S 'إعدادات إضافية' 'Additional settings' 'اللغة|إمكانية الوصول|خيارات المطور' 'Language|Accessibility|Developer options' 2 'tap'),
            (S 'خيارات المطور' 'Developer options' 'تصحيح أخطاء USB|التثبيت عبر USB|تصحيح USB (إعدادات الأمان)' 'USB debugging|Install via USB|USB debugging (Security)' 0 'on'),
            (S 'خيارات المطور' 'Developer options' 'تصحيح أخطاء USB|التثبيت عبر USB|تصحيح USB (إعدادات الأمان)' 'USB debugging|Install via USB|USB debugging (Security)' 1 'on'),
            (S 'خيارات المطور' 'Developer options' 'تصحيح أخطاء USB|التثبيت عبر USB|تصحيح USB (إعدادات الأمان)' 'USB debugging|Install via USB|USB debugging (Security)' 2 'on')) }
        'vivo' { return @(
            (S 'الإعدادات' 'Settings' 'البطارية|إدارة النظام|…' 'Battery|System management|…' 1 'tap'),
            (S 'إدارة النظام' 'System management' 'حول الهاتف|اللغة|…' 'About phone|Language|…' 0 'tap'),
            (S 'معلومات الإصدار' 'Version info' 'إصدار Android|إصدار البرنامج|…' 'Android version|Software version|…' 1 'tap7'),
            (S 'إدارة النظام' 'System management' 'حول الهاتف|اللغة|خيارات المطور' 'About phone|Language|Developer options' 2 'tap'),
            (S 'خيارات المطور' 'Developer options' 'تصحيح أخطاء USB|…|…' 'USB debugging|…|…' 0 'on')) }
        'huawei' { return @(
            (S 'حول الهاتف' 'About phone' 'اسم الجهاز|الطراز|رقم الإصدار' 'Device name|Model|Build number' 2 'tap7'),
            (S 'النظام والتحديثات' 'System & updates' 'اللغة|التاريخ والوقت|خيارات المطور' 'Language|Date & time|Developer options' 2 'tap'),
            (S 'خيارات المطور' 'Developer options' 'تصحيح أخطاء USB|…|…' 'USB debugging|…|…' 0 'on')) }
        'iphone' { return @(
            (S 'الإعدادات' 'Settings' 'الإشعارات|الأصوات|مدة استخدام الجهاز' 'Notifications|Sounds|Screen Time' 2 'tap'),
            (S 'مدة استخدام الجهاز' 'Screen Time' 'حدود التطبيقات|قيود المحتوى والخصوصية|قفل الإعدادات' 'App Limits|Content & Privacy|Lock Screen Time Settings' 1 'tap'),
            (S 'قيود المحتوى والخصوصية' 'Content & Privacy' 'قيود المحتوى والخصوصية|متجر التطبيقات والويب|…' 'Content & Privacy Restrictions|App Store, Media, Web & Games|…' 0 'on'),
            (S 'قيود المحتوى والخصوصية' 'Content & Privacy' 'قيود المحتوى والخصوصية|متجر التطبيقات والويب|…' 'Content & Privacy Restrictions|App Store, Media, Web & Games|…' 1 'tap'),
            (S 'محتوى الويب' 'Web Content' 'غير مقيد|تقييد مواقع البالغين|مواقع مسموحة فقط' 'Unrestricted|Limit Adult Websites|Allowed Websites Only' 1 'check'),
            (S 'السماح بالتغييرات' 'Allow Changes' 'رمز الدخول: عدم السماح|الحسابات: عدم السماح|…' "Passcode: Don't Allow|Accounts: Don't Allow|…" 0 'check'),
            (S 'السماح بالتغييرات' 'Allow Changes' 'رمز الدخول: عدم السماح|الحسابات: عدم السماح|…' "Passcode: Don't Allow|Accounts: Don't Allow|…" 1 'check'),
            (S 'مدة استخدام الجهاز' 'Screen Time' 'حدود التطبيقات|قيود المحتوى والخصوصية|قفل الإعدادات' 'App Limits|Content & Privacy|Lock Screen Time Settings' 2 'tap')) }
        default { return @(
            (S 'عن الهاتف' 'About phone' 'اسم الجهاز|الطراز|رقم الإصدار' 'Device name|Model|Build number' 2 'tap7'),
            (S 'الإعدادات' 'Settings' 'النظام|عن الهاتف|خيارات المطور' 'System|About phone|Developer options' 2 'tap'),
            (S 'خيارات المطور' 'Developer options' 'تصحيح أخطاء USB|…|…' 'USB debugging|…|…' 0 'on')) }
    }
}

function Iphone-Help {
    return (T ("مسار مش بيشتغل على الآيفون: أبل مش بتسمح بالقفل ده غير من جهاز ماك ومع مسح الآيفون. البديل: (مدة استخدام الجهاز) اللي جوه الآيفون. أضعف من مسار، والرقم السري لازم حد تاني يمسكه.`n`n" +
        "1) الإعدادات ← مدة استخدام الجهاز.`n" +
        "2) قيود المحتوى والخصوصية ← شغّلها.`n" +
        "3) متجر التطبيقات والويب ← محتوى الويب ← تقييد مواقع البالغين.`n" +
        "4) السماح بالتغييرات: رمز الدخول والحسابات ← عدم السماح.`n" +
        "5) قفل إعدادات مدة استخدام الجهاز: شخص بتثق فيه يكتب الرقم السري من غير ما تشوفه.") `
       ("Thabat does not work on iPhone: Apple only allows this kind of lock from a Mac, with a full wipe. The alternative is the iPhone's Screen Time. It is weaker than Thabat, and someone else must hold its passcode.`n`n" +
        "1) Settings > Screen Time.`n" +
        "2) Content & Privacy Restrictions > turn on.`n" +
        "3) App Store, Media, Web & Games > Web Content > Limit Adult Websites.`n" +
        "4) Allow Changes: Passcode and Accounts > Don't Allow.`n" +
        "5) Lock Screen Time Settings: someone you trust types the passcode without you seeing it."))
}

$script:Pics = @()
$script:PicIndex = 0

function Refresh-Help {
    if ($rbIphone.Checked) {
        $lblHelp.Text = Iphone-Help
        $script:Pics = @(Help-Pics 'iphone')
    } else {
        $key = $Brands[[Math]::Max(0, $cmbBrand.SelectedIndex)]
        $lblHelp.Text = Brand-Help $key
        $script:Pics = @(Help-Pics $key)
    }
    $script:PicIndex = 0
    $picHelp.Invalidate()
}

function New-RoundPath([single]$x, [single]$y, [single]$w, [single]$h, [single]$r) {
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = 2 * $r
    $p.AddArc($x, $y, $d, $d, 180, 90)
    $p.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
    $p.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
    $p.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
    $p.CloseFigure()
    return $p
}

function Draw-HelpPicture($g, [int]$W, [int]$H) {
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::ClearTypeGridFit
    if ($null -eq $script:CurrentPic) { Draw-Logo $g $W $H; return }
    $g.Clear($Ground)
    $step = $script:CurrentPic
    $rtl = $true
    # Drawn in a 256x250 space, scaled to the box.
    $scale = [Math]::Min($W / 256.0, $H / 250.0)
    $g.TranslateTransform([single](($W - 256 * $scale) / 2), [single](($H - 250 * $scale) / 2))
    $g.ScaleTransform([single]$scale, [single]$scale)
    $W = 256; $H = 250

    # phone body and screen
    $pw = 176; $ph = 222
    $px = [single](($W - $pw) / 2); $py = [single]2
    $g.FillPath((New-Object System.Drawing.SolidBrush (RGB 38 50 56)), (New-RoundPath $px $py $pw $ph 24))
    $sx = $px + 8; $sy = $py + 16; $sw = $pw - 16; $sh = $ph - 30
    $g.FillPath([System.Drawing.Brushes]::White, (New-RoundPath $sx $sy $sw $sh 14))
    $g.FillEllipse((New-Object System.Drawing.SolidBrush (RGB 90 100 104)), ($px + $pw / 2 - 3), ($py + 6), 6, 6)

    $fmt = New-Object System.Drawing.StringFormat
    $fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
    $fmt.Trimming = [System.Drawing.StringTrimming]::EllipsisCharacter
    $flags = [System.Drawing.StringFormatFlags]::NoWrap
    if ($rtl) { $flags = $flags -bor [System.Drawing.StringFormatFlags]::DirectionRightToLeft }
    $fmt.FormatFlags = $flags

    $title = if ($rtl) { $step.TAr } else { $step.TEn }
    $rows = if ($rtl) { $step.RAr } else { $step.REn }
    $fTitle = New-Object System.Drawing.Font('Segoe UI', 9.5, [System.Drawing.FontStyle]::Bold)
    $fRow = New-Object System.Drawing.Font('Segoe UI', 8.5)
    $inkBrush = New-Object System.Drawing.SolidBrush $Ink
    $g.DrawString($title, $fTitle, $inkBrush, (New-Object System.Drawing.RectangleF(($sx + 10), ($sy + 8), ($sw - 20), 24)), $fmt)

    $linePen = New-Object System.Drawing.Pen (RGB 236 230 220)
    $rowH = [single]34
    $ry = $sy + 40
    for ($i = 0; $i -lt $rows.Count; $i++) {
        $hi = ($i -eq $step.Hi)
        $rx = $sx + 6; $rw = $sw - 12
        if ($hi) { $g.FillPath((New-Object System.Drawing.SolidBrush (RGB 221 243 238)), (New-RoundPath $rx ($ry + 1) $rw ($rowH - 3) 9)) }
        # Leave room on the trailing side for a switch or a tick.
        $tx = $rx + 8; $tw = $rw - 16
        if ($hi -and ($step.Mark -eq 'on' -or $step.Mark -eq 'check')) {
            $tw -= 34
            if ($rtl) { $tx += 34 }
        }
        $b = if ($hi) { New-Object System.Drawing.SolidBrush $Brand } else { $inkBrush }
        $g.DrawString($rows[$i], $fRow, $b, (New-Object System.Drawing.RectangleF($tx, $ry, $tw, $rowH)), $fmt)
        $g.DrawLine($linePen, ($sx + 12), ($ry + $rowH), ($sx + $sw - 12), ($ry + $rowH))
        if ($hi) {
            $trailX = if ($rtl) { $rx + 8 } else { $rx + $rw - 38 }
            $midY = $ry + $rowH / 2
            switch ($step.Mark) {
                'on' {
                    $g.FillPath((New-Object System.Drawing.SolidBrush $Brand), (New-RoundPath $trailX ($midY - 8) 30 16 8))
                    $knobX = if ($rtl) { $trailX + 2 } else { $trailX + 16 }
                    $g.FillEllipse([System.Drawing.Brushes]::White, $knobX, ($midY - 6), 12, 12)
                }
                'check' {
                    $pen = New-Object System.Drawing.Pen($Brand, 3)
                    $pen.StartCap = 'Round'; $pen.EndCap = 'Round'
                    $g.DrawLines($pen, [System.Drawing.PointF[]]@(
                        (New-Object System.Drawing.PointF(($trailX + 8), $midY)),
                        (New-Object System.Drawing.PointF(($trailX + 14), ($midY + 6))),
                        (New-Object System.Drawing.PointF(($trailX + 26), ($midY - 7)))))
                }
                default {
                    # A finger tap: a soft circle with a ring.
                    # At the end of the row, so the row's name stays readable.
                    $cx = if ($rtl) { $rx + 24 } else { $rx + $rw - 24 }
                    $cy = $midY + 3
                    $g.FillEllipse((New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(110, 255, 122, 89))), ($cx - 15), ($cy - 15), 30, 30)
                    $g.DrawEllipse((New-Object System.Drawing.Pen ((RGB 255 122 89), 2)), ($cx - 21), ($cy - 21), 42, 42)
                    if ($step.Mark -eq 'tap7') {
                        $bx = if ($rtl) { $cx + 10 } else { $cx - 44 }; $by = $cy - 30
                        $g.FillPath((New-Object System.Drawing.SolidBrush (RGB 255 122 89)), (New-RoundPath $bx $by 34 20 10))
                        $cf = New-Object System.Drawing.StringFormat
                        $cf.Alignment = [System.Drawing.StringAlignment]::Center
                        $cf.LineAlignment = [System.Drawing.StringAlignment]::Center
                        $g.DrawString('×7', $fTitle, [System.Drawing.Brushes]::White, (New-Object System.Drawing.RectangleF($bx, $by, 34, 20)), $cf)
                    }
                }
            }
        }
        $ry += $rowH
    }

    $g.ResetTransform()
}

# ---------------------------------------------------------------- start pages
# One step per page: picture on the right, text on the left, "التالي" at the bottom.
# Pic = $null draws the app's logo.

$Pages = @(
    @{ Pic = $null; Text = ("أهلاً بيك.`n`n" +
        "مسار برنامج للموبايل بيساعد صاحبه يبطّل المواد الإباحية، من غير ما حد حواليه يعرف.`n`n" +
        "•  بيحجب المواقع الإباحية، ولو حصلت محاولة بيقطع النت شوية.`n" +
        "•  مبيتمسحش بسهولة، علشان لحظة ضعف متبوّظش كل اللي فات.`n" +
        "•  كل يوم بيشجّعك بعدّاد الأيام والنقاط.`n`n" +
        "التثبيت مرة واحدة من اللابتوب، وبياخد حوالي ربع ساعة.`n" +
        "دوس (التالي)، وهنمشي مع بعض خطوة خطوة.") },
    @{ Pic = (S 'عن الهاتف' 'About phone' 'اسم الجهاز|الإصدار|رقم الإصدار' 'Device name|Version|Build number' 2 'tap7')
       Text = ("خطوة 1 من 5: فعّل خيارات المطوّر`n`n" +
        "على الموبايل:`n" +
        "1)  افتح الإعدادات، وبعدين (عن الهاتف).`n" +
        "2)  دوّر على (رقم الإصدار) أو (Build number).`n" +
        "     في أوبو وريلمي بيكون جوه (الإصدار)، وفي سامسونج جوه (معلومات البرنامج).`n" +
        "3)  دوس عليه 7 مرات ورا بعض. لو طلب الرقم السري، اكتبه.`n`n" +
        "هتظهر رسالة: (أنت الآن مطوّر).") },
    @{ Pic = (S 'الإعدادات' 'Settings' 'النظام|إعدادات إضافية|خيارات المطوّر' 'System|Additional settings|Developer options' 2 'tap')
       Text = ("خطوة 2 من 5: افتح خيارات المطوّر`n`n" +
        "ارجع لأول صفحة في الإعدادات، وادخل على (خيارات المطوّر).`n`n" +
        "مكانها بيختلف حسب الموبايل:`n" +
        "•  أوبو وريلمي وشاومي: جوه (إعدادات إضافية).`n" +
        "•  سامسونج: في آخر الإعدادات.`n" +
        "•  باقي الموبايلات غالباً: جوه (النظام).") },
    @{ Pic = (S 'خيارات المطوّر' 'Developer options' 'تصحيح أخطاء USB|…|تعطيل مراقبة الأذونات' 'USB debugging|…|Disable permission monitoring' 0 'on')
       Text = ("خطوة 3 من 5: شغّل تصحيح أخطاء USB`n`n" +
        "جوه (خيارات المطوّر):`n" +
        "•  شغّل (تصحيح أخطاء USB) أو (USB debugging)، ودوس (موافق).`n" +
        "•  أوبو وريلمي ووان بلس: انزل لآخر الصفحة، وشغّل كمان (تعطيل مراقبة الأذونات).`n" +
        "•  شاومي: شغّل كمان (التثبيت عبر USB) و(تصحيح أخطاء USB - إعدادات الأمان).") },
    @{ Pic = (S 'السماح بتصحيح USB؟' 'Allow USB debugging?' 'بصمة الكمبيوتر: …|السماح دائماً|سماح' 'Computer fingerprint: …|Always allow from this computer|Allow' 1 'check')
       Text = ("خطوة 4 من 5: وصّل الكابل`n`n" +
        "1)  وصّل الموبايل باللابتوب بكابل USB.`n" +
        "2)  لو الموبايل سألك عن طريقة التوصيل، اختار (نقل الملفات).`n" +
        "3)  بعد ما تدوس (ابدأ)، هيظهر على الموبايل سؤال (السماح بتصحيح أخطاء USB؟).`n" +
        "     علّم على (السماح دائماً من هذا الكمبيوتر)، ودوس (سماح).") },
    @{ Pic = $null; Text = ("خطوة 5 من 5: قبل ما نبدأ`n`n" +
        "•  لو مسار متثبّت قبل كده: البرنامج هيحدّثه بس، وكل تقدّمك هيفضل زي ما هو.`n" +
        "•  لو أول مرة: هيطلب منك تشيل حسابات جوجل من الموبايل لحد ما يخلص، وبعدين ترجّعها. اتأكد إنك عارف باسورداتها.`n" +
        "•  مفيش أي حاجة هتتمسح من الموبايل.`n`n" +
        "لما تكون جاهز، دوس (ابدأ).") }
)

$script:Page = 0
$script:Mode = 'pages'     # pages | running | failed | done
$script:CurrentPic = $null

function Show-StartPage {
    $p = $Pages[$script:Page]
    $lblHelp.Text = $p.Text
    $script:CurrentPic = $p.Pic
    $last = ($script:Page -eq $Pages.Count - 1)
    $chkBackup.Visible = $last
    $btnBack.Visible = ($script:Page -gt 0)
    $btnStart.Text = if ($last) { 'ابدأ' } else { 'التالي' }
    $picHelp.Invalidate()
}

function Draw-Logo($g, [int]$W, [int]$H) {
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::ClearTypeGridFit
    $g.Clear($Ground)
    # soft, cheerful background circles
    $g.FillEllipse((New-Object System.Drawing.SolidBrush $SunSoft), ($W * 0.52), 18, 120, 120)
    $g.FillEllipse((New-Object System.Drawing.SolidBrush $BrandSoft), 10, ($H * 0.55), 150, 150)
    $size = [single]170
    $x = [single](($W - $size) / 2); $y = [single]70
    $g.FillPath((New-Object System.Drawing.SolidBrush $Brand), (New-RoundPath $x $y $size $size 40))
    # Same mark as the app icon: a white peak line and a small sun (108-unit icon grid).
    $u = $size / 108.0
    $g.FillEllipse((New-Object System.Drawing.SolidBrush $Sun), [single]($x + 62 * $u), [single]($y + 28 * $u), [single](16 * $u), [single](16 * $u))
    $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::White, [single](8 * $u))
    $pen.StartCap = 'Round'; $pen.EndCap = 'Round'; $pen.LineJoin = 'Round'
    $g.DrawLines($pen, [System.Drawing.PointF[]]@(
        (New-Object System.Drawing.PointF([single]($x + 34 * $u), [single]($y + 70 * $u))),
        (New-Object System.Drawing.PointF([single]($x + 54 * $u), [single]($y + 38 * $u))),
        (New-Object System.Drawing.PointF([single]($x + 74 * $u), [single]($y + 70 * $u)))))
    $cf = New-Object System.Drawing.StringFormat
    $cf.Alignment = [System.Drawing.StringAlignment]::Center
    $cf.FormatFlags = [System.Drawing.StringFormatFlags]::DirectionRightToLeft
    $g.DrawString('مسار', (New-Object System.Drawing.Font('Segoe UI', 30, [System.Drawing.FontStyle]::Bold)), (New-Object System.Drawing.SolidBrush $Brand), (New-Object System.Drawing.RectangleF(0, ($y + $size + 16), $W, 56)), $cf)
    $g.DrawString('خطوة بخطوة، يوم بيوم', (New-Object System.Drawing.Font('Segoe UI', 12)), (New-Object System.Drawing.SolidBrush $Muted), (New-Object System.Drawing.RectangleF(0, ($y + $size + 74), $W, 30)), $cf)
}

function Draw-Done($g, [int]$W, [int]$H) {
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.Clear($Ground)
    $d = [single][Math]::Min(120, $H - 10)
    $x = [single](($W - $d) / 2); $y = [single](($H - $d) / 2)
    $g.FillEllipse((New-Object System.Drawing.SolidBrush $BrandSoft), ($x - 10), ($y - 10), ($d + 20), ($d + 20))
    $g.FillEllipse((New-Object System.Drawing.SolidBrush $Brand), $x, $y, $d, $d)
    $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::White, ($d * 0.1))
    $pen.StartCap = 'Round'; $pen.EndCap = 'Round'; $pen.LineJoin = 'Round'
    $g.DrawLines($pen, [System.Drawing.PointF[]]@(
        (New-Object System.Drawing.PointF(($x + $d * 0.28), ($y + $d * 0.52))),
        (New-Object System.Drawing.PointF(($x + $d * 0.44), ($y + $d * 0.68))),
        (New-Object System.Drawing.PointF(($x + $d * 0.73), ($y + $d * 0.36)))))
}

function Show-Done([string]$text) {
    $script:Mode = 'done'
    Hide-Actions
    $progress.Visible = $false
    $lstAccounts.Visible = $false
    $picDone.Visible = $true
    $lblMsg.Location = New-Object System.Drawing.Point(290, 212)
    $lblMsg.Size = New-Object System.Drawing.Size(446, 180)
    $lblMsg.Font = New-Object System.Drawing.Font('Segoe UI', 12.5)
    $lblMsg.ForeColor = $Ink
    $lblMsg.Text = $text
    $btnStart.Text = 'إغلاق'
    $picDone.Invalidate()
}

function Apply-Language {
    $script:En = $false
    $form.RightToLeft = 'Yes'
    $form.RightToLeftLayout = $true
    $form.Text = 'مسار - التثبيت'
    $lblTitle.Text = 'تثبيت برنامج مسار'
    $chkBackup.Text = 'خُد نسخة احتياطية من الصور والملفات والواتساب على اللابتوب (مستحسن)'
    $btnClose.Text = 'خروج'
    $btnBack.Text = 'رجوع'
    $lnkDetails.Text = 'التفاصيل التقنية'
    for ($i = 0; $i -lt $StepKeys.Count; $i++) {
        if (-not $StepLabels[$i].Tag) { $StepLabels[$i].Tag = 'pending' }
        Paint-Step $i $StepLabels[$i].Tag
    }
    if ($script:Mode -eq 'pages') { Show-StartPage }
}

# ---------------------------------------------------------------- helpers

function Pump { [System.Windows.Forms.Application]::DoEvents() }

function Wait-UI([int]$ms) {
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.ElapsedMilliseconds -lt $ms -and -not $script:Cancelled) {
        Pump
        Start-Sleep -Milliseconds 50
    }
}

function Set-Msg([string]$text) {
    try { $lblMsg.Text = $text; Pump } catch {}
}

function Write-Log([string]$text) {
    try {
        if ($text.Length -gt 2000) { $text = $text.Substring(0, 2000) + ' ...' }
        $txtLog.AppendText($text.TrimEnd() + "`r`n")
    } catch {}
}

function Paint-Step([int]$index, [string]$state) {
    $glyph = switch ($state) { 'active' { '●' } 'done' { '✓' } 'fail' { '✗' } 'skip' { '–' } default { '○' } }
    $color = switch ($state) { 'active' { $Active } 'done' { $Brand } 'fail' { $Fail } default { $Muted } }
    $style = if ($state -eq 'active' -or $state -eq 'done') { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
    try {
        $StepLabels[$index].Text = $glyph + '  ' + (Step-Name $index)
        $StepLabels[$index].ForeColor = $color
        $StepLabels[$index].Font = New-Object System.Drawing.Font('Segoe UI', 10.5, $style)
    } catch {}
}

function Set-Step([int]$index, [string]$state) {
    $StepLabels[$index].Tag = $state
    Paint-Step $index $state
    if ($state -eq 'active') { $script:CurrentStep = $index }
    Pump
}

function Stop-Cancelled { throw (New-Object System.OperationCanceledException) }

function Box-Options {
    if ($script:En) { return [System.Windows.Forms.MessageBoxOptions]0 }
    return [System.Windows.Forms.MessageBoxOptions]::RtlReading -bor [System.Windows.Forms.MessageBoxOptions]::RightAlign
}

function Ask([string]$text) {
    $answer = [System.Windows.Forms.MessageBox]::Show($form, $text, (T 'مسار' 'Thabat'), 'YesNo', 'Question', 'Button2', (Box-Options))
    return ($answer -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Tell([string]$text) {
    [void][System.Windows.Forms.MessageBox]::Show($form, $text, (T 'مسار' 'Thabat'), 'OK', 'Information', 'Button1', (Box-Options))
}

function Show-Action([string]$text, [scriptblock]$onClick) {
    $btnAction.Text = $text
    $btnAction.Tag = $onClick
    $btnAction.Visible = $true
}

function Show-Action2([string]$text, [scriptblock]$onClick) {
    $btnAction2.Text = $text
    $btnAction2.Tag = $onClick
    $btnAction2.Visible = $true
}

function Hide-Actions {
    $btnAction.Visible = $false
    $btnAction2.Visible = $false
    $lstAccounts.Visible = $false
}

function Run-Adb {
    param(
        [string[]]$ArgList,
        [int]$TimeoutSec = 120,
        [scriptblock]$OnTick = $null
    )
    $quoted = $ArgList | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ } }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $script:Adb
    $psi.Arguments = ($quoted -join ' ')
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.CreateNoWindow = $true
    $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $psi.StandardErrorEncoding = [System.Text.Encoding]::UTF8
    $p = [System.Diagnostics.Process]::Start($psi)
    $outTask = $p.StandardOutput.ReadToEndAsync()
    $errTask = $p.StandardError.ReadToEndAsync()
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $lastTick = -1
    while (-not $p.HasExited) {
        Pump
        Start-Sleep -Milliseconds 80
        if ($OnTick -and [int]$sw.Elapsed.TotalSeconds -ne $lastTick) {
            $lastTick = [int]$sw.Elapsed.TotalSeconds
            & $OnTick
        }
        if ($script:Cancelled -or $sw.Elapsed.TotalSeconds -gt $TimeoutSec) {
            try { $p.Kill() } catch {}
            break
        }
    }
    $p.WaitForExit()
    $out = $outTask.Result
    $err = $errTask.Result
    Write-Log ('> adb ' + $psi.Arguments + "`r`n" + $out + $err)
    if ($script:Cancelled) { Stop-Cancelled }
    return [pscustomobject]@{ Code = $p.ExitCode; Out = $out; Err = $err; All = ($out + "`n" + $err) }
}

function Get-Prop([string]$name) { (Run-Adb @('shell', 'getprop', $name)).Out.Trim() }

function Get-Status([string]$key) {
    $q = Run-Adb @('shell', 'content', 'query', '--uri', "content://$Pkg.status/state")
    if ($q.Out -match ('key=' + $key + ', value=([^\r\n]*)')) { return $Matches[1].Trim() }
    return ''
}

function Open-Url([string]$url) {
    try { Start-Process $url } catch { Write-Log "could not open $url" }
}

# ---------------------------------------------------------------- steps

function Ensure-Adb {
    if (Test-Path $script:Adb) { return }
    Set-Msg (T "بننزّل أدوات أندرويد الرسمية من جوجل.`nده بيحصل مرة واحدة بس، ومحتاج نت على اللابتوب." "Downloading the official Android tools from Google.`nThis happens once and needs internet on the laptop.")
    $progress.Visible = $true
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
    $zip = Join-Path $env:TEMP 'thabat-platform-tools.zip'
    if (Test-Path $zip) { Remove-Item $zip -Force }
    # Read in chunks so the window stays responsive and the bar shows real progress.
    $progress.Style = 'Continuous'
    $progress.Minimum = 0; $progress.Maximum = 100; $progress.Value = 0
    $req = [System.Net.HttpWebRequest]::Create($PlatformToolsUrl)
    $req.Timeout = 30000
    $req.ReadWriteTimeout = 30000
    $resp = $req.GetResponse()
    $total = [double]$resp.ContentLength
    $in = $resp.GetResponseStream()
    $out = [System.IO.File]::Create($zip)
    try {
        $buf = New-Object byte[] 65536
        $got = 0
        $shown = -1
        while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
            $out.Write($buf, 0, $n)
            $got += $n
            if ($total -gt 0) {
                $pct = [int][Math]::Floor(100 * $got / $total)
                if ($pct -ne $shown) {
                    $shown = $pct
                    $progress.Value = [Math]::Min(100, $pct)
                    Set-Msg ("بننزّل أدوات أندرويد الرسمية من جوجل… $pct%`n" +
                             ("{0:N1} من {1:N1} ميجا" -f ($got / 1MB), ($total / 1MB)) +
                             "`n`nده بيحصل مرة واحدة بس، ومحتاج نت على اللابتوب.")
                }
            }
            Pump
            if ($script:Cancelled) { break }
        }
    } finally {
        $out.Close(); $in.Close(); $resp.Close()
    }
    $progress.Style = 'Marquee'
    if ($script:Cancelled) { Stop-Cancelled }
    if (-not (Test-Path $zip) -or (Get-Item $zip).Length -lt 1MB) {
        throw (T "مقدرناش ننزّل أدوات أندرويد.`nاتأكد إن اللابتوب متوصل بالنت وجرّب تاني." "Could not download the Android tools.`nCheck the laptop's internet and try again.")
    }
    Set-Msg (T 'بنفك الأدوات…' 'Extracting the tools…')
    Expand-Archive -Path $zip -DestinationPath $Here -Force
    Remove-Item $zip -Force
    $progress.Visible = $false
    if (-not (Test-Path $script:Adb)) { throw (T 'ملف adb.exe مش موجود بعد فك الأدوات.' 'adb.exe is missing after extracting the tools.') }
}

function Wait-Device {
    $t0 = Get-Date
    Set-Msg (T "وصّل الموبايل باللابتوب بالكابل.`n`nلو أول مرة: لازم (تصحيح أخطاء USB) يكون شغال." "Connect the phone to the laptop with a cable.`n`nFirst time: (USB debugging) must be on.")
    while ($true) {
        $r = Run-Adb @('devices')
        $lines = @($r.Out -split "`r?`n" | Where-Object { $_ -match "`t" })
        if ($lines.Count -gt 1) {
            Set-Msg (T 'فيه أكتر من جهاز متوصل. سيب موبايل واحد بس.' 'More than one device is connected. Keep only one phone.')
        } elseif ($lines.Count -eq 1) {
            $state = ($lines[0] -split "`t")[1].Trim()
            if ($state -eq 'device') { return }
            if ($state -eq 'unauthorized') {
                Set-Msg (T "بص على شاشة الموبايل: هتلاقي رسالة بتسأل تسمح للابتوب ده.`n`nعلّم على (السماح دائماً) ودوس (موافق)." "Look at the phone: it asks whether to allow this laptop.`n`nTick (Always allow) and tap (Allow).")
            } else {
                Set-Msg ((T 'الموبايل متوصل بس حالته: ' 'The phone is connected but its state is: ') + $state + "`n" + (T 'افصل الكابل ووصّله تاني.' 'Unplug the cable and plug it in again.'))
            }
        } elseif (((Get-Date) - $t0).TotalSeconds -gt 20) {
            Set-Msg (T ("اللابتوب مش شايف الموبايل لسه.`n`n" +
                "• اتأكد إن (تصحيح أخطاء USB) شغال.`n" +
                "• اسحب شريط الإشعارات على الموبايل واختار (نقل الملفات).`n" +
                "• جرّب كابل تاني أو مدخل USB تاني.") `
                ("The laptop cannot see the phone yet.`n`n" +
                "• Check that (USB debugging) is on.`n" +
                "• On the phone, pull down the notifications and choose (File transfer).`n" +
                "• Try another cable or USB port."))
        }
        Wait-UI 1500
        if ($script:Cancelled) { Stop-Cancelled }
    }
}

function Check-Device {
    $script:Model = Get-Prop 'ro.product.model'
    $script:Maker = Get-Prop 'ro.product.manufacturer'
    $script:Serial = (Run-Adb @('get-serialno')).Out.Trim()
    $release = Get-Prop 'ro.build.version.release'
    $sdkText = Get-Prop 'ro.build.version.sdk'
    $sdk = 0
    [void][int]::TryParse($sdkText, [ref]$sdk)
    Set-Msg ((T 'الموبايل: ' 'Phone: ') + "$($script:Maker) $($script:Model) — Android $release")
    if ($sdk -lt 29) { throw ((T 'البرنامج محتاج أندرويد 10 أو أحدث. الموبايل ده أندرويد ' 'Thabat needs Android 10 or newer. This phone runs Android ') + $release) }

    $users = (Run-Adb @('shell', 'pm', 'list', 'users')).Out
    if (([regex]::Matches($users, 'UserInfo\{')).Count -gt 1) {
        throw (T "على الموبايل أكتر من مستخدم (غالباً استنساخ التطبيقات أو المساحة التانية).`n`nاقفلهم من الإعدادات وجرّب تاني." "The phone has more than one user (usually App cloner or a second space).`n`nTurn them off in Settings and try again.")
    }

    $dp = (Run-Adb @('shell', 'dumpsys', 'device_policy')).Out
    $script:OursIsOwner = $false
    if ($dp -match '(?s)Device Owner:.*?admin=ComponentInfo\{([^/}]+)/') {
        if ($Matches[1] -eq $Pkg) {
            $script:OursIsOwner = $true
        } else {
            throw ((T 'فيه برنامج إدارة تاني متفعّل على الموبايل ده: ' 'Another management app is active on this phone: ') + $Matches[1])
        }
    }
}

# Which app file to install: the test build if present, else by brand.
function Pick-Apk {
    $test = Join-Path $Here 'thabat-test.apk'
    if (Test-Path $test) { return $test }
    if ($script:Maker -match '(?i)oppo|realme|oneplus') { return (Join-Path $Here 'thabat-oplus.apk') }
    return (Join-Path $Here 'thabat-standard.apk')
}

$BackupItems = @(
    @{ Path = '/sdcard/DCIM'; Ar = 'صور وفيديوهات الكاميرا'; En = 'Camera photos and videos'; Sub = '' },
    @{ Path = '/sdcard/Pictures'; Ar = 'الصور'; En = 'Pictures'; Sub = '' },
    @{ Path = '/sdcard/Movies'; Ar = 'الفيديوهات'; En = 'Videos'; Sub = '' },
    @{ Path = '/sdcard/Documents'; Ar = 'المستندات'; En = 'Documents'; Sub = '' },
    @{ Path = '/sdcard/Download'; Ar = 'التنزيلات'; En = 'Downloads'; Sub = '' },
    @{ Path = '/sdcard/WhatsApp'; Ar = 'الواتساب'; En = 'WhatsApp'; Sub = '' },
    @{ Path = '/sdcard/Android/media/com.whatsapp/WhatsApp'; Ar = 'الواتساب'; En = 'WhatsApp'; Sub = 'Android-media' }
)

# Backups go to C:\Thabat-Backups: outside OneDrive, so nothing is uploaded.
function Backup-Root {
    $sys = $env:SystemDrive
    if (-not $sys) { $sys = 'C:' }
    return (Join-Path ($sys + '\') 'Thabat-Backups')
}

function Do-Backup {
    $present = @()
    $totalKb = [int64]0
    foreach ($item in $BackupItems) {
        $du = (Run-Adb @('shell', "du -sk '$($item.Path)' 2>/dev/null")).Out.Trim()
        if ($du -match '^(\d+)\s') {
            $present += $item
            $totalKb += [int64]$Matches[1]
        }
    }
    if ($present.Count -eq 0) { Set-Msg (T 'مفيش ملفات تتنسخ.' 'Nothing to back up.'); return 'skip' }
    $root = Backup-Root
    $drive = Split-Path -Qualifier $root
    $free = [int64]0
    try { $free = [int64](Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$drive'").FreeSpace } catch {}
    $needMb = [math]::Ceiling($totalKb / 1024)
    $freeMb = [math]::Floor($free / 1MB)
    if ($free -gt 0 -and ($totalKb * 1024) -gt ($free - 2GB)) {
        $q = (T "النسخة الاحتياطية محتاجة حوالي $needMb ميجا، والمساحة الفاضية على $drive حوالي $freeMb ميجا بس.`n`nنكمّل من غير نسخة احتياطية؟ (التثبيت مش بيمسح أي حاجة من الموبايل.)" `
                "The backup needs about $needMb MB, but $drive has only about $freeMb MB free.`n`nContinue without a backup? (Installing deletes nothing from the phone.)")
        if (Ask $q) { return 'skip' }
        Stop-Cancelled
    }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmm'
    $safeModel = ($script:Model -replace '[^\w\-]', '_')
    $dest = Join-Path $root ($safeModel + '_' + $stamp)
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    $script:BackupDir = $dest
    $progress.Visible = $true
    foreach ($item in $present) {
        $target = if ($item.Sub) { Join-Path $dest $item.Sub } else { $dest }
        New-Item -ItemType Directory -Force -Path $target | Out-Null
        $label = T $item.Ar $item.En
        $started = Get-Date
        $r = Run-Adb @('pull', '-a', $item.Path, $target) -TimeoutSec 14400 -OnTick {
            $elapsed = [TimeSpan]::FromSeconds([int]((Get-Date) - $started).TotalSeconds)
            Set-Msg ((T 'بناخد نسخة من: ' 'Backing up: ') + $label + "`n`n" + (T 'الحجم الكلي تقريباً: ' 'Total size, about: ') + "$needMb MB`n" + (T 'الوقت: ' 'Time: ') + $elapsed.ToString('hh\:mm\:ss') + "`n`n" + $dest)
        }
        if ($r.Code -ne 0) { Write-Log "warning: $($item.Path) was not copied completely." }
    }
    $progress.Visible = $false
    Set-Msg ((T 'النسخة الاحتياطية خلصت: ' 'Backup finished: ') + $dest)
    return 'done'
}

# ---- accounts

# Accounts whose app is installed (Android ignores the rest), with the app that owns them.
function Get-Accounts {
    $out = (Run-Adb @('shell', 'dumpsys', 'account')).Out
    $owner = @{}
    foreach ($m in [regex]::Matches($out, 'AuthenticatorDescription \{type=([^}]+)\}, ComponentInfo\{([^/}]+)/')) {
        $owner[$m.Groups[1].Value] = $m.Groups[2].Value
    }
    $live = @{}
    foreach ($m in [regex]::Matches($out, 'AuthenticatorDescription \{type=([^}]+)\}')) { $live[$m.Groups[1].Value] = $true }
    $list = @()
    $seen = @{}
    foreach ($m in [regex]::Matches($out, 'Account \{name=([^,]+), type=([^}]+)\}')) {
        $type = $m.Groups[2].Value
        if ($live.Count -gt 0 -and -not $live.ContainsKey($type)) { continue }
        $key = $m.Groups[1].Value + '|' + $type
        if (-not $seen.ContainsKey($key)) {
            $seen[$key] = $true
            $pkgName = if ($owner.ContainsKey($type)) { $owner[$type] } else { '' }
            $list += [pscustomobject]@{ Name = $m.Groups[1].Value; Type = $type; Package = $pkgName }
        }
    }
    return $list   # callers wrap the result in @() so 0 or 1 accounts still give an array
}

function Friendly-Type([string]$type) {
    switch -Regex ($type) {
        '^com\.google$' { return (T 'جوجل' 'Google') }
        'heytap|oppo|coloros|oplus' { return (T 'حساب أوبو' 'OPPO account') }
        'whatsapp' { return (T 'واتساب' 'WhatsApp') }
        'telegram' { return (T 'تيليجرام' 'Telegram') }
        'facebook' { return (T 'فيسبوك' 'Facebook') }
        'microsoft|outlook' { return (T 'مايكروسوفت' 'Microsoft') }
        'samsung|osp' { return (T 'حساب سامسونج' 'Samsung account') }
        'xiaomi' { return (T 'حساب شاومي' 'Xiaomi account') }
        default { return $type }
    }
}

# Before anything changes: every Google account must have a password the person has tried.
function Confirm-Passwords([object[]]$accounts) {
    $google = @($accounts | Where-Object { $_.Type -eq 'com.google' })
    $others = @($accounts | Where-Object { $_.Type -ne 'com.google' })

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = T 'قبل ما نكمّل: الحسابات' 'Before we continue: accounts'
    $dlg.ClientSize = New-Object System.Drawing.Size(640, 520)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.BackColor = $Ground
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    if (-not $script:En) { $dlg.RightToLeft = 'Yes'; $dlg.RightToLeftLayout = $true }

    $info = New-Object System.Windows.Forms.Label
    $info.Location = New-Object System.Drawing.Point(16, 12)
    $info.Size = New-Object System.Drawing.Size(608, 150)
    $info.Text = (T ("على الموبايل $($accounts.Count) حساب.`n`n" +
        "أندرويد مش بيسمح بالتفعيل وفيه حسابات، فالمعالج هيوقف التطبيقات بتاعتها لحظات ويرجّعها. " +
        "حسابات جوجل ممكن تتشال مؤقتاً، والإيميلات والأسماء والصور مش بتتمسح من جوجل.`n`n" +
        "المهم: لازم تكون عارف باسورد كل حساب جوجل، علشان لو اتطلب منك ترجع تدخل. علّم على كل حساب بعد ما تجرّب الباسورد بتاعه.") `
        ("The phone has $($accounts.Count) account(s).`n`n" +
        "Android does not allow activation while accounts exist, so the wizard pauses their apps for a moment and brings them back. " +
        "Google accounts may be removed for a while; emails, contacts and photos stay on Google.`n`n" +
        "Important: you must know the password of every Google account in case you need to sign in again. Tick each account after trying its password."))
    $dlg.Controls.Add($info)

    $chk = New-Object System.Windows.Forms.CheckedListBox
    $chk.Location = New-Object System.Drawing.Point(16, 168)
    $chk.Size = New-Object System.Drawing.Size(608, 150)
    $chk.CheckOnClick = $true
    foreach ($g in $google) { [void]$chk.Items.Add((T 'جرّبت الباسورد ونجح: ' 'Password tried and works: ') + $g.Name) }
    $dlg.Controls.Add($chk)

    $otherLbl = New-Object System.Windows.Forms.Label
    $otherLbl.Location = New-Object System.Drawing.Point(16, 324)
    $otherLbl.Size = New-Object System.Drawing.Size(608, 60)
    $names = ($others | ForEach-Object { Friendly-Type $_.Type } | Select-Object -Unique) -join '، '
    $otherLbl.Text = if ($others.Count -gt 0) { (T 'حسابات تطبيقات (بترجع لوحدها غالباً): ' 'App accounts (usually come back by themselves): ') + $names } else { '' }
    $dlg.Controls.Add($otherLbl)

    $btnLogin = New-Object System.Windows.Forms.Button
    $btnLogin.Location = New-Object System.Drawing.Point(16, 392)
    $btnLogin.Size = New-Object System.Drawing.Size(296, 36)
    $btnLogin.Text = T 'جرّب الباسورد للحساب المختار' 'Try the password of the selected account'
    $btnLogin.Add_Click({
        $i = $chk.SelectedIndex
        if ($i -lt 0) { $i = 0 }
        if ($google.Count -gt 0) {
            $email = [Uri]::EscapeDataString($google[$i].Name)
            Open-Url ("https://accounts.google.com/AccountChooser?Email=$email&continue=https%3A%2F%2Fmyaccount.google.com%2F")
        }
    })
    $dlg.Controls.Add($btnLogin)

    $btnForgot = New-Object System.Windows.Forms.Button
    $btnForgot.Location = New-Object System.Drawing.Point(328, 392)
    $btnForgot.Size = New-Object System.Drawing.Size(296, 36)
    $btnForgot.Text = T 'نسيت الباسورد' 'I forgot the password'
    $btnForgot.Add_Click({ Open-Url 'https://accounts.google.com/signin/recovery' })
    $dlg.Controls.Add($btnForgot)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Location = New-Object System.Drawing.Point(16, 460)
    $ok.Size = New-Object System.Drawing.Size(296, 44)
    $ok.Text = T 'كمّل' 'Continue'
    $ok.BackColor = $Brand
    $ok.ForeColor = [System.Drawing.Color]::White
    $ok.Enabled = ($google.Count -eq 0)
    $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $dlg.Controls.Add($ok)
    $chk.Add_ItemCheck({
        param($s, $e)
        $checked = $chk.CheckedItems.Count
        if ($e.NewValue -eq 'Checked') { $checked++ } else { $checked-- }
        $ok.Enabled = ($checked -ge $google.Count)
    })

    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Location = New-Object System.Drawing.Point(328, 460)
    $cancel.Size = New-Object System.Drawing.Size(296, 44)
    $cancel.Text = T 'وقف التثبيت' 'Stop the installation'
    $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($cancel)
    $dlg.AcceptButton = $ok
    $dlg.CancelButton = $cancel

    $result = $dlg.ShowDialog($form)
    $dlg.Dispose()
    if ($result -ne [System.Windows.Forms.DialogResult]::OK) {
        throw (T 'التثبيت اتوقف. مفيش أي حاجة اتغيّرت على الموبايل.' 'Installation stopped. Nothing was changed on the phone.')
    }
}

function Frozen-File { return (Join-Path $StateDir ('frozen-' + ($script:Serial -replace '[^\w\-]', '_') + '.txt')) }

function Save-Frozen { Set-Content -Path (Frozen-File) -Value ($script:Frozen -join "`r`n") -Encoding UTF8 }

# Pauses the apps that own accounts ("freeze"); Android then does not count their accounts.
function Freeze-Accounts([object[]]$accounts) {
    $pkgs = @($accounts | Where-Object { $_.Package -and $_.Package -ne $Pkg } | ForEach-Object { $_.Package } | Select-Object -Unique)
    # Google Play services last, so Google accounts are paused only after the others.
    $pkgs = @($pkgs | Where-Object { $_ -ne 'com.google.android.gms' }) + @($pkgs | Where-Object { $_ -eq 'com.google.android.gms' })
    foreach ($p in $pkgs) {
        $r = Run-Adb @('shell', 'pm', 'disable-user', '--user', '0', $p)
        if ($r.All -match 'disabled-user') {
            $script:Frozen += $p
            Save-Frozen
        }
    }
}

function Unfreeze-All {
    if ($script:Frozen.Count -eq 0) { return }
    foreach ($p in @($script:Frozen)) {
        Run-Adb @('shell', 'pm', 'enable', '--user', '0', $p) | Out-Null
    }
    $script:Frozen = @()
    try { Remove-Item (Frozen-File) -Force -ErrorAction SilentlyContinue } catch {}
}

# A previous run stopped half-way: bring paused apps back first.
function Restore-Frozen {
    $f = Frozen-File
    if (-not (Test-Path $f)) { return }
    $list = @(Get-Content $f | Where-Object { $_.Trim() })
    if ($list.Count -eq 0) { Remove-Item $f -Force; return }
    Set-Msg (T 'المرة اللي فاتت وقفت في النص. بنرجّع التطبيقات اللي اتوقفت…' 'The last run stopped half-way. Bringing paused apps back…')
    $script:Frozen = $list
    Unfreeze-All
}

function Open-AccountsScreen {
    Run-Adb @('shell', 'am', 'start', '-a', 'android.settings.SYNC_SETTINGS') | Out-Null
}

# Whatever could not be paused is removed by hand, one by one.
function Remove-Remaining {
    $accounts = @(Get-Accounts)
    if ($accounts.Count -eq 0) { return }
    $lstAccounts.Visible = $true
    Show-Action (T 'افتح شاشة الحسابات تاني' 'Open the accounts screen again') { Open-AccountsScreen }
    Open-AccountsScreen
    while ($true) {
        $accounts = @(Get-Accounts)
        $lstAccounts.Items.Clear()
        foreach ($a in $accounts) { [void]$lstAccounts.Items.Add((Friendly-Type $a.Type) + '  —  ' + $a.Name) }
        if ($accounts.Count -eq 0) { break }
        Set-Msg ((T "الحسابات دي مقدرناش نوقفها لوحدنا. على الموبايل اتفتحت شاشة الحسابات:`nشيلها واحد واحد: افتح الحساب ← القايمة ← إزالة الحساب.`n`nفاضل: " `
                    "These accounts could not be paused automatically. The accounts screen is open on the phone:`nremove them one by one: open the account > menu > Remove account.`n`nLeft: ") + $accounts.Count)
        Wait-UI 3000
        if ($script:Cancelled) { Stop-Cancelled }
    }
    Hide-Actions
}

function Install-And-Activate {
    $apk = Pick-Apk
    if (-not (Test-Path $apk)) { throw ((T 'ملف البرنامج مش موجود: ' 'The app file is missing: ') + (Split-Path -Leaf $apk)) }
    Set-Msg (T 'بنثبّت البرنامج على الموبايل…' 'Installing the app on the phone…')
    $progress.Visible = $true
    $r = Run-Adb @('install', '-r', '-t', $apk) -TimeoutSec 300
    if ($r.All -match 'INSTALL_FAILED_UPDATE_INCOMPATIBLE') {
        # An earlier build signed with another key; this path only runs before activation.
        Set-Msg (T 'فيه نسخة قديمة على الموبايل. بنشيلها ونثبّت الجديدة…' 'An older build is on the phone. Replacing it…')
        Run-Adb @('uninstall', $Pkg) | Out-Null
        $r = Run-Adb @('install', '-r', '-t', $apk) -TimeoutSec 300
    }
    if ($r.All -notmatch 'Success') {
        if ($r.All -match 'USER_RESTRICTED') { throw (T 'الموبايل مانع تثبيت التطبيقات حالياً.' 'The phone is blocking app installs right now.') }
        throw ((T "التثبيت فشل:`n" "Installation failed:`n") + $r.All.Trim())
    }

    try {
        Set-Msg (T 'بنوقف تطبيقات الحسابات لحظات…' 'Pausing the account apps for a moment…')
        Freeze-Accounts $script:AccountsBefore
        Remove-Remaining

        Set-Msg (T 'بنفعّل البرنامج…' 'Activating the app…')
        $r = Run-Adb @('shell', 'dpm', 'set-device-owner', $Admin)
        if ($r.All -notmatch 'Success') {
            if ($r.All -match 'ProvisioningPreCondition 99') {
                throw (T "الموبايل رفض التفعيل (كود 99).`n`nده قفل خاص بموبايلات أوبو وريلمي ووان بلس. ابعت صورة الشاشة دي للي بيساعدك." `
                         "The phone refused activation (code 99).`n`nThis is an OPPO / realme / OnePlus lock. Send a screenshot of this window to whoever helps you.")
            }
            if ($r.All -match 'accounts') { throw (T 'لسه فيه حساب على الموبايل. جرّب تاني.' 'There is still an account on the phone. Try again.') }
            if ($r.All -match 'several users') { throw (T 'على الموبايل أكتر من مستخدم. اقفل استنساخ التطبيقات أو المساحة التانية.' 'The phone has more than one user. Turn off App cloner or the second space.') }
            if ($r.All -match 'SecurityException') {
                throw ((T "الموبايل رفض التفعيل.`nلو الموبايل أوبو: من خيارات المطوّر شغّل (تعطيل مراقبة الأذونات) وجرّب تاني.`n`n" "The phone refused activation.`nOn OPPO: in Developer options, turn on (Disable permission monitoring) and try again.`n`n") + $r.All.Trim())
            }
            throw ((T "التفعيل فشل:`n" "Activation failed:`n") + $r.All.Trim())
        }
    } finally {
        # Paused apps come back right away, whatever happened.
        Unfreeze-All
    }
    Grant-Permissions
    $progress.Visible = $false
}

# Permissions only adb can give. None is fatal: the app shows a one-tap fix instead.
function Grant-Permissions {
    Run-Adb @('shell', 'pm', 'grant', $Pkg, 'android.permission.WRITE_SECURE_SETTINGS') | Out-Null
    Run-Adb @('shell', 'appops', 'set', $Pkg, 'GET_USAGE_STATS', 'allow') | Out-Null
    Run-Adb @('shell', 'appops', 'set', $Pkg, 'SYSTEM_ALERT_WINDOW', 'allow') | Out-Null
    Run-Adb @('shell', 'dumpsys', 'deviceidle', 'whitelist', "+$Pkg") | Out-Null
}

function Wait-Setup {
    Run-Adb @('shell', 'am', 'start', '-n', "$Pkg/.MainActivity") | Out-Null
    $script:UserDone = $false
    Show-Action (T 'خلصت الإعداد على الموبايل' 'I finished the setup on the phone') { $script:UserDone = $true }
    Set-Msg (T ("كمّل على شاشة الموبايل:`nاللغة ← الشروط ← مدد الانتظار ← كود الطوارئ.`n`n" +
                "اكتب كود الطوارئ على ورقة قبل ما تدوس (ابدأ الحماية).") `
               ("Continue on the phone:`nLanguage > Terms > Waiting periods > Emergency code.`n`n" +
                "Write the emergency code on paper before tapping (Start protection)."))
    while (-not $script:UserDone) {
        if ((Get-Status 'setup_complete') -eq '1') { break }
        $state = (Run-Adb @('get-state')).Out.Trim()
        if ($state -ne 'device') { break }
        Wait-UI 3000
        if ($script:Cancelled) { Stop-Cancelled }
    }
    Hide-Actions
}

# If the app could not switch its accessibility service on by itself, open the
# screen on the phone and wait (up to 3 minutes) for the person to switch it on.
function Ensure-Watch {
    Wait-UI 4000
    if ((Get-Status 'watch_enabled') -eq '1') { return }
    Run-Adb @('shell', 'am', 'start', '-a', 'android.settings.ACCESSIBILITY_SETTINGS') | Out-Null
    Set-Msg (T "فاضل خطوة صغيرة على الموبايل:`n`nاتفتحت شاشة (إمكانية الوصول).`nدوس على (مسار) ← شغّله ← (سماح)." `
               "One small step on the phone:`n`nThe (Accessibility) screen is open.`nTap (Thabat) > turn it on > (Allow).")
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt 180) {
        Wait-UI 3000
        if ($script:Cancelled) { Stop-Cancelled }
        if ((Get-Status 'watch_enabled') -eq '1') { return }
        if ((Run-Adb @('get-state')).Out.Trim() -ne 'device') { return }
    }
}

# Brings removed Google accounts back one by one; app accounts return when their app opens.
function Restore-Accounts {
    $now = @(Get-Accounts)
    $missing = @($script:AccountsBefore | Where-Object {
        $b = $_
        -not ($now | Where-Object { $_.Name -eq $b.Name -and $_.Type -eq $b.Type })
    })
    $missingGoogle = @($missing | Where-Object { $_.Type -eq 'com.google' })
    $missingApps = @($missing | Where-Object { $_.Type -ne 'com.google' })

    foreach ($g in $missingGoogle) {
        $script:UserSkip = $false
        Show-Action (T 'افتح شاشة إضافة الحساب تاني' 'Open the add-account screen again') {
            Run-Adb @('shell', 'am', 'start', '-a', 'android.settings.ADD_ACCOUNT_SETTINGS', '--esa', 'account_types', 'com.google') | Out-Null
        }
        Show-Action2 (T 'تخطّي الحساب ده' 'Skip this account') { $script:UserSkip = $true }
        Run-Adb @('shell', 'am', 'start', '-a', 'android.settings.ADD_ACCOUNT_SETTINGS', '--esa', 'account_types', 'com.google') | Out-Null
        while (-not $script:UserSkip) {
            Set-Msg ((T "على الموبايل: سجّل الدخول تاني بالحساب ده:`n`n" "On the phone, sign in again with this account:`n`n") + $g.Name)
            $back = @(Get-Accounts | Where-Object { $_.Name -eq $g.Name -and $_.Type -eq 'com.google' })
            if ($back.Count -gt 0) { break }
            Wait-UI 3000
            if ($script:Cancelled) { Stop-Cancelled }
            if ((Run-Adb @('get-state')).Out.Trim() -ne 'device') { break }
        }
        Hide-Actions
    }
    if ($missingApps.Count -gt 0) {
        $names = ($missingApps | ForEach-Object { Friendly-Type $_.Type } | Select-Object -Unique) -join '، '
        Write-Log ("app accounts that return when their app is opened: " + $names)
    }
}

function Upgrade-Existing {
    $apk = Pick-Apk
    if (-not (Test-Path $apk)) { throw ((T 'ملف البرنامج مش موجود: ' 'The app file is missing: ') + (Split-Path -Leaf $apk)) }
    Set-Msg (T 'البرنامج متفعّل على الموبايل ده بالفعل. بنحدّثه للنسخة اللي معانا…' 'Thabat is already active on this phone. Updating it…')
    $progress.Visible = $true
    Run-Adb @('shell', 'content', 'call', '--uri', "content://$Pkg.status", '--method', 'dev_lift') | Out-Null
    $r = Run-Adb @('install', '-r', '-t', $apk) -TimeoutSec 300
    if ($r.All -notmatch 'Success') { throw ((T "التحديث فشل:`n" "Update failed:`n") + $r.All.Trim()) }
    Grant-Permissions
    Run-Adb @('shell', 'content', 'call', '--uri', "content://$Pkg.status", '--method', 'dev_resume') | Out-Null
    Run-Adb @('shell', 'am', 'start', '-n', "$Pkg/.MainActivity") | Out-Null
    $progress.Visible = $false
}

# ---------------------------------------------------------------- main flow

function Show-Page([bool]$run) {
    foreach ($c in $StartControls) { $c.Visible = -not $run }
    foreach ($c in $RunControls) { $c.Visible = $run }
    if ($run) {
        Hide-Actions
        $progress.Visible = $false
        $txtLog.Visible = $false
        $picDone.Visible = $false
        $lblMsg.Location = New-Object System.Drawing.Point(290, 66)
        $lblMsg.Size = New-Object System.Drawing.Size(446, 190)
        $lblMsg.Font = New-Object System.Drawing.Font('Segoe UI', 11)
    } else {
        Show-StartPage
    }
}

function Show-IphoneGuide {
    Tell (T "مسار مش بيتثبّت على الآيفون. اتبع الخطوات والصور اللي على الشاشة دي على الآيفون نفسه." `
            "Thabat cannot be installed on an iPhone. Follow the steps and pictures on this screen on the iPhone itself.")
}

function Start-Install {
    $script:Mode = 'running'
    $btnStart.Enabled = $false
    $script:Cancelled = $false
    Show-Page $true
    for ($i = 0; $i -lt $StepKeys.Count; $i++) { Set-Step $i 'pending' }
    try {
        Set-Step 0 'active'; Ensure-Adb; Set-Step 0 'done'
        Set-Step 1 'active'; Wait-Device; Set-Step 1 'done'
        Set-Step 2 'active'; Check-Device; Restore-Frozen; Set-Step 2 'done'

        if ($script:OursIsOwner) {
            Set-Step 3 'skip'; Set-Step 4 'skip'
            Set-Step 5 'active'; Upgrade-Existing; Set-Step 5 'done'
            Set-Step 6 'active'
            if ((Get-Status 'setup_complete') -ne '1') { Wait-Setup }
            Ensure-Watch
            Set-Step 6 'done'
            Set-Step 7 'skip'
            Show-Done ("خلصنا!`n`nمسار اتحدّث للنسخة الجديدة، وكل تقدّمك زي ما هو.`n`nتقدر تفصل الكابل وتقفل البرنامج ده.")
            return
        }

        Set-Step 3 'active'
        if ($chkBackup.Checked) {
            $b = Do-Backup
            if ($b -eq 'done') { Set-Step 3 'done' } else { Set-Step 3 'skip' }
        } else { Set-Step 3 'skip' }

        Set-Step 4 'active'
        $script:AccountsBefore = @(Get-Accounts)
        if ($script:AccountsBefore.Count -gt 0) { Confirm-Passwords $script:AccountsBefore }
        Set-Step 4 'done'

        Set-Step 5 'active'; Install-And-Activate; Set-Step 5 'done'
        Set-Step 6 'active'; Wait-Setup; Ensure-Watch; Set-Step 6 'done'
        Set-Step 7 'active'; Restore-Accounts; Set-Step 7 'done'

        # Release builds switch adb off when the installer reports back.
        Run-Adb @('shell', 'content', 'call', '--uri', "content://$Pkg.status", '--method', 'installer_done') | Out-Null

        $msg = "خلصنا!`n`nمسار متثبّت وشغال على الموبايل.`n`nتقدر تفصل الكابل وتقفل البرنامج ده."
        if ($script:BackupDir) { $msg += "`n`nالنسخة الاحتياطية في:`n" + $script:BackupDir }
        Show-Done $msg
    } catch [System.OperationCanceledException] {
        $script:Mode = 'failed'
        Set-Msg 'اتلغى.'
    } catch {
        $script:Mode = 'failed'
        Set-Step $script:CurrentStep 'fail'
        Set-Msg $_.Exception.Message
        Write-Log ($_ | Out-String)
        try { $btnStart.Text = T 'حاول تاني' 'Try again' } catch {}
    } finally {
        try { if ($script:Frozen.Count -gt 0) { Unfreeze-All } } catch {}
        try {
            $progress.Visible = $false
            $btnStart.Enabled = $true
        } catch {}
    }
}

$btnStart.Add_Click({
    switch ($script:Mode) {
        'pages' {
            if ($script:Page -lt $Pages.Count - 1) { $script:Page++; Show-StartPage } else { Start-Install }
        }
        'done' { $form.Close() }
        default { Start-Install }
    }
})
$btnBack.Add_Click({ if ($script:Page -gt 0) { $script:Page--; Show-StartPage } })
$lnkDetails.Add_LinkClicked({
    $txtLog.Visible = -not $txtLog.Visible
    if ($txtLog.Visible) { $txtLog.BringToFront() }
})
$picDone.Add_Paint({ param($sender, $e) try { Draw-Done $e.Graphics $picDone.Width $picDone.Height } catch {} })
$btnAction.Add_Click({ if ($btnAction.Tag) { & $btnAction.Tag } })
$btnAction2.Add_Click({ if ($btnAction2.Tag) { & $btnAction2.Tag } })
$picHelp.Add_Paint({ param($sender, $e) try { Draw-HelpPicture $e.Graphics $picHelp.Width $picHelp.Height } catch {} })
$btnClose.Add_Click({ $script:Cancelled = $true; $form.Close() })
$form.Add_FormClosing({ $script:Cancelled = $true })

# Apply-Language fills the brand list and selects the first brand. (Selecting before the
# list is filled throws, and the window never opened.)
Apply-Language
Show-Page $false

# CI only: build every start-page state and draw every picture without showing the
# window, then save a preview sheet. Any error stops the script with a non-zero exit.
if ($env:THABAT_SMOKE_TEST) {
    $tileW = 300; $tileH = 440
    $tiles = New-Object System.Collections.ArrayList
    for ($k = 0; $k -lt $Pages.Count; $k++) {
        $script:Page = $k
        Show-StartPage
        $bmp = New-Object System.Drawing.Bitmap $tileW, $tileH
        $gfx = [System.Drawing.Graphics]::FromImage($bmp)
        Draw-HelpPicture $gfx $tileW $tileH
        $gfx.Dispose()
        [void]$tiles.Add($bmp)
    }
    Show-Page $true
    Set-Msg 'test'
    Show-Done 'test'
    $bmp = New-Object System.Drawing.Bitmap $tileW, $tileH
    $gfx = [System.Drawing.Graphics]::FromImage($bmp)
    $gfx.Clear($Ground)
    Draw-Done $gfx $tileW 140
    $gfx.Dispose()
    [void]$tiles.Add($bmp)
    Show-Page $false
    $script:Mode = 'pages'; $script:Page = 0; Show-StartPage
    if ($env:THABAT_SMOKE_OUT) {
        $cols = 4
        $rows = [Math]::Ceiling($tiles.Count / $cols)
        $sheet = New-Object System.Drawing.Bitmap ($cols * $tileW), ($rows * $tileH)
        $g = [System.Drawing.Graphics]::FromImage($sheet)
        $g.Clear([System.Drawing.Color]::White)
        for ($t = 0; $t -lt $tiles.Count; $t++) {
            $g.DrawImage($tiles[$t], ($t % $cols) * $tileW, [Math]::Floor($t / $cols) * $tileH)
        }
        $g.Dispose()
        $sheet.Save($env:THABAT_SMOKE_OUT, [System.Drawing.Imaging.ImageFormat]::Png)
    }
    Write-Host "Smoke test passed: $($tiles.Count) preview tiles."
    exit 0
}

try {
    [void]$form.ShowDialog()
} finally {
    if (Test-Path $script:Adb) {
        try { & $script:Adb kill-server 2>$null | Out-Null } catch {}
    }
}
