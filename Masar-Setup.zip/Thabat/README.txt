﻿مسار — التثبيت / Thabat — Setup
================================

عربي
----
1) على الموبايل (مرة واحدة): فعّل (تصحيح أخطاء USB).
   الخطوات لكل ماركة بتظهر في أول شاشة في البرنامج.
2) وصّل الموبايل باللابتوب بالكابل.
3) دبل كليك على  «Thabat Setup.exe»  ← اختار اللغة والماركة ← «ابدأ».
4) اعمل اللي المعالج بيقوله. جنب كل خطوة بتخلص بتظهر ✓.

لو ويندوز قال «Windows protected your PC»: دوس More info ← Run anyway.
النسخة الاحتياطية بتتحفظ في  C:\Thabat-Backups  (برا OneDrive).
لو البرنامج مفتحش: دبل كليك على Install.bat.

English
-------
1) On the phone (once): turn on (USB debugging).
   The first screen of the program shows the steps for each brand.
2) Connect the phone to the laptop with a cable.
3) Double-click  "Thabat Setup.exe"  > choose the language and brand > "Start".
4) Do what the wizard says. Each finished step gets a ✓.

If Windows says "Windows protected your PC": click More info > Run anyway.
The backup is saved in  C:\Thabat-Backups  (outside OneDrive).
If the program does not open: double-click Install.bat.
